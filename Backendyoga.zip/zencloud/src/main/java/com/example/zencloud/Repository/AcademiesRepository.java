package com.example.zencloud.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.zencloud.Model.Academies;

public interface AcademiesRepository extends JpaRepository<Academies, Long> {

}
